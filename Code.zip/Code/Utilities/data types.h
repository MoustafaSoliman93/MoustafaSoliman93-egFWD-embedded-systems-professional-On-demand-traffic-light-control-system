/*
 * data_types.h
 *
 * Created: 8/10/2022 9:50:45 PM
 *  Author: moust
 */ 


#ifndef DATA_TYPES_H_
#define DATA_TYPES_H_

typedef unsigned char uint8_t;
typedef enum mode { Pedestrian_mode_t, Normal_mode_t} Mode_t;


#endif /* DATA TYPES_H_ */