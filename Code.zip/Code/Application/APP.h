/*
 * APP.h
 *
 * Created: 8/10/2022 9:47:56 PM
 *  Author: moust
 */ 



#ifndef APP_H_
#define APP_H_

#include "../Service Layer/service.h"

void appstart();

extern uint8_t mode;
extern uint8_t sec_passed;
extern Mode_t Mode;
extern uint8_t time;

#endif /* APP_H_ */