/*
 * APP.c
 *
 * Created: 8/10/2022 9:47:47 PM
 *  Author: moust
 */ 
#include "APP.h"




void appstart()
{
	system_initialize();			// initialize the system
	while (1)
	{
		
		while (!sec_passed && (Mode == Normal_mode_t)) // wait until a sec passed
		{
			;
		}
		if (Mode == Normal_mode_t)					// if no one pressed the button
		{
			sec_passed = 0;							// the sec passed indicator return to 0
			normal_mode(& time);					// apply the normal mode according o the current time
		}
		else if (Mode ==  Pedestrian_mode_t)		// if somebody pressed the button
		{
			pedestrian_mode(& time);				// apply the  pedestrian mode
			Mode = Normal_mode_t;					// return the mode to normal mode
			sec_passed = 1;
		}
	}
}