/*
 * service.h
 *
 * Created: 8/14/2022 3:39:46 AM
 *  Author: moust
 */ 


#ifndef SERVICE_H_
#define SERVICE_H_

#include "../ECUAL/LED/LED.h"
#include "../ECUAL/Button/button.h"

void normal_mode(uint8_t * sec_num);
void  pedestrian_mode(uint8_t * sec_num);

void N_stage_1();
void N_stage_2();
void N_stage_3();
void N_stage_4();
void system_initialize ();



#endif /* SERVICE_H_ */