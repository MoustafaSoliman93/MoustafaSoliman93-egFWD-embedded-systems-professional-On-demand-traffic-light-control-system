/*
 * service.c
 *
 * Created: 8/14/2022 3:39:33 AM
 *  Author: moust
 */ 
#include "service.h"

void normal_mode(uint8_t * sec_num)
{
	if (*sec_num < 5)								// 0-5 secs
	{
		N_stage_1();
	}
	else if ((*sec_num >=5) && (*sec_num < 10))		// 5-10 secs
	{
		N_stage_2();
	}
	else if ((*sec_num >=10) && (*sec_num < 15))	// 10-15 secs
	{
		N_stage_3();
	}
	else if ((*sec_num >=15) && (*sec_num < 20))	//15-20 secs
	{
		N_stage_4();
	}
}
void pedestrian_mode(uint8_t * sec_num)
{
	if(* sec_num < 5)			// if in stage one
	{
		*sec_num = 5;			// go to step 2 by setting the time to 5
	}
	else						// in any other stage do nothing
	{
		// stay in the same step
	}
}

void N_stage_1()
{
	/***** cars leds *****/
	LED_ON(C_port,G);
	LED_OFF(C_port,Y);
	LED_OFF(C_port,R);
	/***** bedesterian leds *****/
	LED_OFF(P_port,G);
	LED_OFF(P_port,Y);
	LED_ON(P_port,R);
}
void N_stage_2()
{
	/***** cars leds *****/
	LED_ON(C_port,G);
	LED_toggle(C_port,Y);
	LED_OFF(C_port,R);
	/***** bedesterian leds *****/
	LED_OFF(P_port,G);
	LED_toggle(P_port,Y);
	LED_ON(P_port,R);
}
void N_stage_3()
{
	/***** cars leds *****/
	LED_OFF(C_port,G);
	LED_OFF(C_port,Y);
	LED_ON(C_port,R);
	/***** bedesterian leds *****/
	LED_ON(P_port,G);
	LED_OFF(P_port,Y);
	LED_OFF(P_port,R);
}
void N_stage_4()
{
	/***** cars leds *****/
	LED_OFF(C_port,G);
	LED_toggle(C_port,Y);
	LED_ON(C_port,R);
	/***** bedesterian leds *****/
	LED_ON(P_port,G);
	LED_toggle(P_port,Y);
	LED_OFF(P_port,R);
}
 
void system_initialize()
{
	button_init(D, 2); // initialize button pin
		
	LED_init(C_port, G); //initialize car green led
	LED_init(C_port, Y); //initialize car yellow led
	LED_init(C_port, R); //initialize car red led
	
	LED_init(P_port, G); //initialize pedestrian green led
	LED_init(P_port, Y); //initialize pedestrian yellow led
	LED_init(P_port, R); //initialize pedestrian red led
	
	sei(); // enable global interrupts
	
	N_stage_1(); // initializing the system in stage 1
	
	timer0_OF_init(211); // initialize system timer 0
	timer0_start(3);     // start system timer 0
	
	INT0_init_R();		// initialize INT 0 to detect rising edge
}