/*
 * timer0.c
 *
 * Created: 8/12/2022 8:41:55 PM
 *  Author: moust
 */ 

#include "timer0.h"



void timer0_OF_init(uint8_t T0_reg)			// initialize timer 0
{
	TCNT0 = T0_reg;
	TIMSK |= (1 << TOIE0);
}
void timer0_start(uint8_t prescaler)		//start timer 0
{
	TCCR0 |= (prescaler << CS00);
}
void timer0_stop()		//stop timer 0
{
	TCCR0 &= ~(0x07 << CS00);
}
