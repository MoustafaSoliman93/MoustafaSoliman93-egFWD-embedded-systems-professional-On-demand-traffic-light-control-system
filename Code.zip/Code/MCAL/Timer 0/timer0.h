/*
 * timer0.h
 *
 * Created: 8/12/2022 8:42:25 PM
 *  Author: moust
 */ 


#ifndef TIMER0_H
#define TIMER0_H


#include "../../MCAL/DIO/DIO.h"

void timer0_OF_init(uint8_t T0_reg);
void timer0_start(uint8_t prescaler);
void timer0_stop();





#endif /* TIMER0_H_ */