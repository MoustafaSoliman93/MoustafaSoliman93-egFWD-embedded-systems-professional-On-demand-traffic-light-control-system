/*
 * INT0.h
 *
 * Created: 8/12/2022 10:55:31 PM
 *  Author: moust
 */ 


#ifndef INT0_H_
#define INT0_H_

#include "../../MCAL/DIO/DIO.h"


void INT0_init_R();
void INT0_init_F();
 void INT0_stop();



#endif /* INT0_H_ */