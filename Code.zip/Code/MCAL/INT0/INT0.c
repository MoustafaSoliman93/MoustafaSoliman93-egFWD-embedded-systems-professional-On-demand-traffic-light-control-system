/*
 * INT0.c
 *
 * Created: 8/12/2022 10:55:41 PM
 *  Author: moust
 */ 
#include "INT0.h"


void INT0_init_R()			//initialize INT0 to detect rising edge
{
	MCUCR |= (0x03 << ISC00);   // The rising edge of INT0 generates an interrupt request
	GICR |= (1 << INT0); // enable external interrupt INT0
}
void INT0_init_F()			//initialize INT0 to detect falling edge
{
	MCUCR |= (0x01 << ISC01);   // The rising edge of INT0 generates an interrupt request
	GICR |= (1 << INT0); // enable external interrupt INT0
}

 void INT0_stop()			// stop INT0
 {
 	GICR &= ~(1 << INT0);
	MCUCR &= ~(0x03 << ISC00);
 }
