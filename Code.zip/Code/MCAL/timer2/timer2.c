/*
 * timer2.c
 *
 * Created: 8/12/2022 9:33:16 PM
 *  Author: moust
 */ 
#include "timer2.h"



void timer2_OF_init(uint8_t T2_reg)			// initialize timer 2
{
	TIMSK |= (1 << TOIE2);
	TCNT2 = T2_reg;
}

void timer2_start()				// start timer 2
{
	TCCR2 |= 0x04;
}
void timer2_stop()			//stop timer 2
{
	TCCR2 &= ~(0x07);
	
}
