/*
 * timer2.h
 *
 * Created: 8/12/2022 9:35:23 PM
 *  Author: moust
 */ 


#ifndef TIMER2_H_
#define TIMER2_H_

#include "../DIO/DIO.h"

void timer2_OF_init(uint8_t T2_reg);
void timer2_start();
void timer2_stop();

#endif /* TIMER2_H_ */