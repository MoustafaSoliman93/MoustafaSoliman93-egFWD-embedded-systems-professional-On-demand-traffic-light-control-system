/*
 * DIO.c
 *
 * Created: 8/10/2022 9:48:19 PM
 *  Author: moust
 */ 
#include "DIO.h"
void pin_init(uint8_t port , uint8_t pin , uint8_t direction)
{
		switch (port)
			{
				case A:
					if(direction) DDRA |= (1 << pin);
					else DDRA &= ~(1 << pin);
					break;
				case B:
					if(direction) DDRB |= (1 << pin);
					else DDRA &= ~(1 << pin);
					break;
				case C:
					if(direction) DDRC |= (1 << pin);
					else DDRA &= ~(1 << pin);
					break;
				case D:
					if(direction) DDRD |= (1 << pin);
					else DDRA &= ~(1 << pin);
					break;
			}		
}
void pin_write (uint8_t port, uint8_t pin, uint8_t value)
{
	switch (port)
	{
		case A:
			if (value) PORTA |= (1 << pin);
			else PORTA &= ~(1 << pin);
			break;
		case B:
			if (value) PORTB |= (1 << pin);
			else PORTB &= ~(1 << pin);
			break;
		case C:
			if (value) PORTC |= (1 << pin);
			else PORTC &= ~(1 << pin);
			break;
		case D:
			if (value) PORTC |= (1 << pin);
			else PORTC &= ~(1 << pin);
			break;
	}
}
void pin_read (uint8_t port, uint8_t pin, uint8_t* value)
{
	switch (port)
	{
		case A:
			*(value) = (PINA & (1 << pin)) >> pin;
			break;
		case B:
			*(value) = (PINB & (1 << pin)) >> pin;
			break;
		case C:
			*(value) = (PINC & (1 << pin)) >> pin;
			break;
		case D:
			*(value) = (PIND & (1 << pin)) >> pin;
			break;
	}
}
void pin_toggle (uint8_t port, uint8_t pin)
{
	switch (port)
	{
		case A :
			PORTA ^= (1 << pin);
			break;
		case B :
			PORTB ^= (1 << pin);
			break;
		case C :
			PORTC ^= (1 << pin);
			break;
		case D :
			PORTD ^= (1 << pin);
			break;
	}
}