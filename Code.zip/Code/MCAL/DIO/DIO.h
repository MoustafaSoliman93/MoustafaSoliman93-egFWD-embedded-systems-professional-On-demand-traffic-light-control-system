/*
 * DIO.h
 *
 * Created: 8/10/2022 9:48:09 PM
 *  Author: moust
 */ 


#ifndef DIO_H_
#define DIO_H_

#include "../../Utilities/data types.h"
#include "avr/io.h"
#include "avr/interrupt.h"

#define A 'A'
#define B 'B'
#define C 'C'
#define D 'D'
#define IN 0
#define OUT 1
#define HIGH 1
#define LOW 0

#define C_port A
#define P_port B

#define Button_port D
#define Button_pin 2

#define G 0
#define Y 1
#define R 2



void pin_init (uint8_t port, uint8_t pin, uint8_t direction);
void pin_write (uint8_t port, uint8_t pin, uint8_t value);
void pin_read (uint8_t port, uint8_t pin, uint8_t* value);
void pin_toggle (uint8_t port, uint8_t pin);






#endif /* DIO_H_ */