/*
 * button.h
 *
 * Created: 8/10/2022 9:45:39 PM
 *  Author: moust
 */ 


#ifndef BUTTON_H_
#define BUTTON_H_

#include "../../MCAL/INT0/INT0.h"
#include "../../MCAL/timer2/timer2.h"
#include "../../MCAL/DIO/DIO.h"





void button_init(uint8_t , uint8_t );
void button_read(uint8_t button_port, uint8_t button_pin, uint8_t* value);



#endif /* BUTTON_H_ */