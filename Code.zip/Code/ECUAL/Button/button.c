/*
 * button.c
 *
 * Created: 8/10/2022 9:45:27 PM
 *  Author: moust
 */ 

#include "button.h"


void button_init(uint8_t port, uint8_t pin)			// button initialize
{
	pin_init(Button_port, Button_pin, IN);
}
void button_read(uint8_t port, uint8_t pin, uint8_t* value)			// read button
{
	pin_read(Button_port, Button_pin, value);
}