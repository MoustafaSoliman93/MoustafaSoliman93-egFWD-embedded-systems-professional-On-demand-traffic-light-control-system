/*
 * LED.h
 *
 * Created: 8/10/2022 9:45:57 PM
 *  Author: moust
 */ 


#ifndef LED_H_
#define LED_H_


#include "../../MCAL/Timer 0/timer0.h"
#include "../../MCAL/DIO/DIO.h"



void LED_init(uint8_t LED_port, uint8_t LED_pin);
void LED_ON(uint8_t LED_port, uint8_t LED_pin);
void LED_OFF(uint8_t LED_port, uint8_t LED_pin);
void LED_toggle(uint8_t LED_port, uint8_t LED_pin);

#endif /* LED_H_ */