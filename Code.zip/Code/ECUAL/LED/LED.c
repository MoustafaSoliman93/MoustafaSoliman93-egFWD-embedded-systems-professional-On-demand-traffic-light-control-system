/*
 * LED.c
 *
 * Created: 8/10/2022 9:46:07 PM
 *  Author: moust
 */ 
#include "LED.h"

void LED_init(uint8_t LED_port, uint8_t LED_pin)		// initialize led
{
	pin_init(LED_port, LED_pin, OUT);
}
void LED_ON(uint8_t LED_port, uint8_t LED_pin)			// turn led on
{
	pin_write(LED_port, LED_pin, HIGH);
}
void LED_OFF(uint8_t LED_port, uint8_t LED_pin)			// turn led off
{
	pin_write(LED_port, LED_pin, LOW);
}
void LED_toggle(uint8_t LED_port, uint8_t LED_pin)		// toggle led
{
	pin_toggle(LED_port, LED_pin);
}



