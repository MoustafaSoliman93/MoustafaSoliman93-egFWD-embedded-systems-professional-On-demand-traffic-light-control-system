/*
 * On-demand Traffic light control.c
 *
 * Created: 8/10/2022 8:33:58 PM
 * Author : moust
 */ 
#include "Application/APP.h"




Mode_t Mode = Normal_mode_t;
uint8_t timer0_OF = 0;
uint8_t timer2_OF = 0;
uint8_t time = 0;
uint8_t sec_passed = 0;


ISR(TIMER0_OVF_vect)
{
	timer0_OF ++;
	if (timer0_OF == 62)		// check if 1 sec passed
	{
		timer0_OF = 0;
		TCNT0 = 247;
		time ++;				// increase the time counter by 1
		sec_passed = 1;			// set the sec indicator to 1
		if (time == 20)			// check if one system cycle passed
		{
			time = 0;			// set the time counter to 0
			INT0_init_R();		//init the external interuppt INT0
		}
	}
}
ISR(INT0_vect)
{
	INT0_stop();					// stop the external INT0 to prevent many pressing detection
	if (!timer2_OF)					// if its the first press 
	{
		timer2_OF_init(247);		// start timer 2
		timer2_start();				// start timer 2
		GIFR |= (1 << INTF0);
	}
	else							// if interrupt occurs after the small delay
	{		
		Mode =  Pedestrian_mode_t;	//	set the mode to Pedestrian mode
		GIFR |= (1 << INTF0);
	}
}

ISR(TIMER2_OVF_vect)
{
	timer2_OF ++;
	if (timer2_OF == 7)			// wait for small delay 
	{
		INT0_init_F();			//reinitialize INT0 to detect falling edge
	}
	if (timer2_OF == 62)		//after one second 
	{
		timer2_OF = 0;			
		timer2_stop();			// stop timer 2
		INT0_init_R();			// change INT0 to interrupt on rising edge (if still pressed after one sec it will not detect the falling edge)
	}
}

int main(void)
{	
	
	while (1) 
    {
		appstart();				// start the application
    }
}

